#ifndef LINES_H
#define LINES_H

#include <stdint.h>

typedef struct
{
	float x,y,z;
	float vel;
	int floorcnt;
} Line;

#define NUM_LINES 4000

#endif

#ifndef __cplusplus
extern "C"{
#endif

extern void initLines(void);
extern float random(float max);
extern void initPoint(int i);
extern void initPoints(void);
extern void updatePoints(void);
extern void drawPoints(void);
extern void resizeLineHandler(int width, int height);
extern void displayLineHandler(void);
extern void keyLineHandler(unsigned char key, int x, int y);
extern void idleLineHandler(void);
#ifndef __cplusplus
}
#endif
