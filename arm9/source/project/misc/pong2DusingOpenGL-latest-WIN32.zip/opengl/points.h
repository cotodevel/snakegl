#ifndef POINTS_H
#define POINTS_H

#include <stdint.h>

typedef struct
{
	float x,y,z;
	float vel;
	int floorcnt;
} PointRec;

#define NUM_POINTS 4000
#define FLOORCNT_INIT 200


#endif

#ifndef __cplusplus
extern "C"{
#endif

extern float random(float max);
extern PointRec Points[NUM_POINTS];
extern void initPoint(int i);
extern void initPoints(void);
extern void updatePoints(void);
extern void drawPoints(void);
extern void resizePointHandler(int width, int height);
extern void displayPointHandler(void);
extern void keyPointHandler(unsigned char key, int x, int y);
extern void idlePointHandler(void);
#ifndef __cplusplus
}
#endif
